# CPU

![Braaainz.](oredict:oc:cpu1)

[电脑](../general/computer.md) 和 [服务器](server1.md)的中央处理器. 定义了 [电脑](../general/computer.md)架构, 以及连接组件上限 级别越高，每tick可以进行的函数调用越多 或者说，高级就牛逼

CPU的组件上限：
- T1: 8 
- T2: 12
- T3: 16

[服务器](server1.md)里面, 这个数量可以通过安装 [组件总线](componentBus1.md)提升

如果连接数量超过上限，会无法开机，运行中的机器会宕机。