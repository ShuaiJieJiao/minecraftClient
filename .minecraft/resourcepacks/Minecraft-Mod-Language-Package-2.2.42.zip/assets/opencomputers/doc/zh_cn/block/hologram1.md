# 全息投影机

![Is this the real life? Is this just fantasy?](oredict:oc:hologram1)

一个巨大的显示屏, i.e. 可以显示独立的三维图形,就是那种全息的3D，偏振光原理那种（高中课本会讲）

2级显示屏, 分辨率不变但是支持电脑定制每个像素的颜色

可以被[扳手](../item/wrench.md)旋转 [, 

可以在范围内任意放缩显示 
