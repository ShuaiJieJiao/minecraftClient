# 3D打印制品

![Any way you want me.](block:OpenComputers:print)

3D打印制品由 [3D打印机](printer.md)制造. 他们主要作为装饰用途出现, 但也可以收发红石信号来扩展出一点点小的功能.

可以通过放入 [3D打印机](printer.md)进行回收. 可以重用一点用来打印的 [油墨](../item/chamelium.md). 打印的颜料是不会回收的.

长按shift（默认的OC扩展tip）,将会显示出当前打印制品的激活状态.

兼容Forge Multipart. 在他们不碰撞，且单个方块的形状数量不超出上限时,可以被放入单个方块的空间，比如火炬，拉杆，线缆等.
