# 染色方块

![So... blank.](oredict:oc:chameliumBlock)

几篇[印刷电路板](../item/chamelium.md) 可以被变成特殊装饰用途的有色方块. 

可以被原版任意染色

