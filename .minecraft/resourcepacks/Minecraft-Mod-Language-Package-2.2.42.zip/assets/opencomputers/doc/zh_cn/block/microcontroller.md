# Microcontroller

![Don't belittle it.](block:OpenComputers:microcontroller)

单片机通过[单片机箱](../item/microcontrollerCase1.md) 在[组装机](assembler.md)组装. 相比电脑他们弱得多 , 但是便宜. 另外他们无法和外界物件交互.

单片机可以携带多种组件, 如 [CPU](../item/cpu1.md), [内存](../item/ram1.md), 扩展卡. 单片机无法携带[硬盘](../item/hdd1.md)只能烧入[E2PROM](../item/eeprom.md), 
相比[机箱](case1.md)他们可以用一些特别的升级 比如[活塞升级](../item/pistonUpgrade.md).
