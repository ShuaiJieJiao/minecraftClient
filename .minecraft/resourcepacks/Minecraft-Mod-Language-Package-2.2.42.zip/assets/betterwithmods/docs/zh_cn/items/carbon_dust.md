# Carbon Dust

煤粉
![Coal Dust](item:betterwithmods:material:18)

木炭粉
![Charcoal Dust](item:betterwithmods:material:27)