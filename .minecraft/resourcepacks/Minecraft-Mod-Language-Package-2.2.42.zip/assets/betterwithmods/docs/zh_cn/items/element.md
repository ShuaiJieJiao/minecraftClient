# Heating Element

![Heating Element](item:betterwithmods:material@27)

 [炭火炉](../blocks/hibachi.md) 的合成材料之一