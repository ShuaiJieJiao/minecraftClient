# Plate Armor

一套拥有极高耐久度的装甲。可以防御大多数伤害。使用 [熔魂钢](soulforged_steel.md) 制造。

![Plate Helmet](item:betterwithmods:steel_helmet)
![Plate Chest](item:betterwithmods:steel_chest)
![Plate Leggings](item:betterwithmods:steel_pants)
![Plate Boots](item:betterwithmods:steel_boots)

 

