# Filament

![Filament](item:betterwithmods:material@19)

[光源方块](../blocks/light.md) 的合成材料之一。