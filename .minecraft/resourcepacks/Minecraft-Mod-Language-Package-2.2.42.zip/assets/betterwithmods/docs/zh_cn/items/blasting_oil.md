# Blasting Oil

![Blasting Oil](item:betterwithmods:material@29)

爆破油膏是通过混合浓缩地狱火和动物油脂来制作的。这是一种极其易爆的物质，任何快速的敲击或震荡都很可能会导致爆炸。 