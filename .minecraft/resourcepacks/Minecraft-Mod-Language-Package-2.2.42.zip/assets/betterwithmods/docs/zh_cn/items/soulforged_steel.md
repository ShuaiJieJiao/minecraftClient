# Soulforged Steel

![Soulforged Steel](item:betterwithmods:material@14)

熔魂钢（Soulforged Steel，SFS）是一种 [碳](carbon_dust.md) 铁合金，这两种物质在 [灵魂](../blocks/soul_urn.md) 的力量下融合。

熔魂钢具有极高的耐久度和优良的延展性，可以用于许多用途，比如:

 * [熔魂钢护甲](plate_armor.md).
 
 * [熔魂钢块](blocks:betterwithmods:steel_block) 