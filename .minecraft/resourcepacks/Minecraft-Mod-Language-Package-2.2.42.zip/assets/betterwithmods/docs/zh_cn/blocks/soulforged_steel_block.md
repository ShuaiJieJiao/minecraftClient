# 熔魂钢块

![熔魂钢块](block:betterwithmods:steel_block)

在[Anvil](anvil.md)中由16个[熔魂钢锭](../items/soulforged_steel.md)创建的熔魂钢块是一个非常强大的块，不能被活塞推动，不能被凋零破坏。它需要使用[熔魂钢镐或者熔魂钢鹤嘴锄](../items/refined_tools.md)破坏。
由于制造此方块的灵魂数量庞大，在与[Beacon](../hardcore/beacons.md)组合时，它可以将玩家的灵魂绑定到其位置。
  
