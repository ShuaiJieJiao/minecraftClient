# 变速箱

![变速箱](block:betterwithmods:wooden_gearbox@0)

变速箱用于传递机械动力。
动能必须输入到这个面，并可以输出到任何其他面。
当给予红石信号是，变速箱不会传输机械动力。


可以通过Shift+右键点击来使其旋转，以使其更容易使用。

## 损坏的变速箱
![破损变速箱](block:betterwithmods:wooden_broken_gearbox@0)

If a 变速箱 breaks from being overpowered, it can be repaired by clicking or crafting it with two [Gears](../items/gear.md) or
