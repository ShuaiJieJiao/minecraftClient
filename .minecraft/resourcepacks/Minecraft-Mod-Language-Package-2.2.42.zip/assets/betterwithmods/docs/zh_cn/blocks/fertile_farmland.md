# 肥沃的田地

![肥沃的田地](block:betterwithmods:fertile_farmland)

用骨粉右键耕地，就可以创建肥沃的田地
除非你使用[培植皿](planter.md)，否则肥料会随机被用完，需要重新播撒。
{hcbonemeal?由于HCBonemeal这是使用骨粉的唯一方法：     }


