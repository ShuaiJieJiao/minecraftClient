# 泥土台阶

![泥土台阶](block:betterwithmods:dirt_slab)

可以长草或菌丝的泥土半砖。用铲子右键可以形成草径半砖。不能放置在上半砖的位置。
