# Hardcore Hunger 
({hchunger?Enabled:Disabled}