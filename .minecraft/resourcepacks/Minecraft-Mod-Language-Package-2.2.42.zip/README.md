# CurseForgeAutoUpload
利用 CurseForge 提供的 api，实现每周定时上传，从而大幅度减少人工上传带来的问题
